import { useQuery } from "@tanstack/react-query";

export function useAuth() {
  const { data: user, isLoading, error } = useQuery({
    queryKey: ["/api/auth/user"],
    retry: false,
    refetchOnWindowFocus: true,
  });

  // Don't auto-redirect on auth errors to allow manual navigation

  return {
    user,
    isLoading,
    isAuthenticated: !!user,
    error,
  };
}
