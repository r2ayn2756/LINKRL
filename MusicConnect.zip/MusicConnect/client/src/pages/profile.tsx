import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, Video, Music, Camera, Calendar, MapPin, Briefcase, Award, ExternalLink } from "lucide-react";
import { format } from "date-fns";
import type { UserMedia, UserExperience } from "@shared/schema";

const mediaSchema = z.object({
  type: z.enum(["video", "audio", "image"]),
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  mediaUrl: z.string().url("Please enter a valid URL"),
  thumbnailUrl: z.string().url("Please enter a valid URL").optional(),
});

const experienceSchema = z.object({
  title: z.string().min(1, "Title is required"),
  organization: z.string().optional(),
  location: z.string().optional(),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  description: z.string().optional(),
  type: z.enum(["band", "gig", "education", "award"]),
});

export default function Profile() {
  const { user, isLoading } = useAuth();
  const { toast } = useToast();
  const [mediaDialogOpen, setMediaDialogOpen] = useState(false);
  const [experienceDialogOpen, setExperienceDialogOpen] = useState(false);

  const { data: userMedia = [], isLoading: mediaLoading } = useQuery({
    queryKey: ["/api/users", user?.id, "media"],
    enabled: !!user?.id,
  });

  const { data: userExperiences = [], isLoading: experiencesLoading } = useQuery({
    queryKey: ["/api/users", user?.id, "experiences"],
    enabled: !!user?.id,
  });

  const mediaForm = useForm({
    resolver: zodResolver(mediaSchema),
    defaultValues: {
      type: "video" as const,
      title: "",
      description: "",
      mediaUrl: "",
      thumbnailUrl: "",
    },
  });

  const experienceForm = useForm({
    resolver: zodResolver(experienceSchema),
    defaultValues: {
      title: "",
      organization: "",
      location: "",
      startDate: "",
      endDate: "",
      description: "",
      type: "band" as const,
    },
  });

  const addMediaMutation = useMutation({
    mutationFn: async (data: z.infer<typeof mediaSchema>) => {
      return apiRequest("POST", "/api/users/media", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", user?.id, "media"] });
      setMediaDialogOpen(false);
      mediaForm.reset();
      toast({
        title: "Media added successfully",
        description: "Your media has been added to your profile.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add media. Please try again.",
        variant: "destructive",
      });
    },
  });

  const addExperienceMutation = useMutation({
    mutationFn: async (data: z.infer<typeof experienceSchema>) => {
      const payload = {
        ...data,
        startDate: data.startDate ? new Date(data.startDate).toISOString() : null,
        endDate: data.endDate ? new Date(data.endDate).toISOString() : null,
      };
      return apiRequest("POST", "/api/users/experiences", payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/users", user?.id, "experiences"] });
      setExperienceDialogOpen(false);
      experienceForm.reset();
      toast({
        title: "Experience added successfully",
        description: "Your experience has been added to your profile.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add experience. Please try again.",
        variant: "destructive",
      });
    },
  });

  const getMediaIcon = (type: string) => {
    switch (type) {
      case "video": return <Video className="w-4 h-4" />;
      case "audio": return <Music className="w-4 h-4" />;
      case "image": return <Camera className="w-4 h-4" />;
      default: return <Video className="w-4 h-4" />;
    }
  };

  const getExperienceIcon = (type: string) => {
    switch (type) {
      case "band": return <Music className="w-4 h-4" />;
      case "gig": return <Calendar className="w-4 h-4" />;
      case "education": return <Briefcase className="w-4 h-4" />;
      case "award": return <Award className="w-4 h-4" />;
      default: return <Briefcase className="w-4 h-4" />;
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardContent className="flex items-center justify-center h-32">
            <div className="forest-gradient w-8 h-8 rounded-lg animate-pulse"></div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!user && !isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardContent className="flex items-center justify-center h-32 flex-col space-y-4">
            <p className="text-slate-400">Please log in to view your profile.</p>
            <a
              href="/api/login"
              className="px-4 py-2 bg-forest-600 hover:bg-forest-700 text-white rounded-lg transition-colors"
            >
              Sign in with Google
            </a>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Profile Header */}
      <Card className="mb-8">
        <CardContent className="p-8">
          <div className="flex items-start gap-6">
            <Avatar className="w-24 h-24">
              <AvatarImage src={user?.profileImageUrl || ""} />
              <AvatarFallback className="text-2xl forest-gradient text-white">
                {user?.firstName?.[0]}{user?.lastName?.[0]}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h1 className="text-3xl font-bold text-white mb-2">
                {user?.firstName} {user?.lastName}
              </h1>
              {user?.title && (
                <p className="text-forest-400 text-lg mb-2">{user.title}</p>
              )}
              {user?.location && (
                <div className="flex items-center gap-2 text-slate-400 mb-4">
                  <MapPin className="w-4 h-4" />
                  <span>{user.location}</span>
                </div>
              )}
              {user?.bio && (
                <p className="text-slate-300 leading-relaxed">{user.bio}</p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs for Media and Experience */}
      <Tabs defaultValue="media" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="media">Media & Portfolio</TabsTrigger>
          <TabsTrigger value="experience">Experience</TabsTrigger>
        </TabsList>

        {/* Media Tab */}
        <TabsContent value="media" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-white">Media & Portfolio</h2>
            <Dialog open={mediaDialogOpen} onOpenChange={setMediaDialogOpen}>
              <DialogTrigger asChild>
                <Button className="forest-gradient hover:opacity-90">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Media
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Media</DialogTitle>
                </DialogHeader>
                <Form {...mediaForm}>
                  <form onSubmit={mediaForm.handleSubmit((data) => addMediaMutation.mutate(data))} className="space-y-4">
                    <FormField
                      control={mediaForm.control}
                      name="type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select media type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="video">Video</SelectItem>
                              <SelectItem value="audio">Audio</SelectItem>
                              <SelectItem value="image">Image</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={mediaForm.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Title</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter media title" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={mediaForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Describe your media" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={mediaForm.control}
                      name="mediaUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Media URL</FormLabel>
                          <FormControl>
                            <Input placeholder="https://youtube.com/watch?v=..." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={mediaForm.control}
                      name="thumbnailUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Thumbnail URL (Optional)</FormLabel>
                          <FormControl>
                            <Input placeholder="https://example.com/thumbnail.jpg" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button type="submit" className="w-full forest-gradient" disabled={addMediaMutation.isPending}>
                      {addMediaMutation.isPending ? "Adding..." : "Add Media"}
                    </Button>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>

          {mediaLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <div className="aspect-video bg-slate-700 rounded-t-lg"></div>
                  <CardContent className="p-4">
                    <div className="h-4 bg-slate-700 rounded mb-2"></div>
                    <div className="h-3 bg-slate-700 rounded w-2/3"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : userMedia.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {userMedia.map((media: UserMedia) => (
                <Card key={media.id} className="group hover:ring-2 hover:ring-forest-400 transition-all">
                  <div className="aspect-video bg-slate-800 rounded-t-lg relative overflow-hidden">
                    {media.thumbnailUrl ? (
                      <img 
                        src={media.thumbnailUrl} 
                        alt={media.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        {getMediaIcon(media.type)}
                      </div>
                    )}
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Button asChild variant="secondary" size="sm">
                        <a href={media.mediaUrl} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="w-4 h-4 mr-2" />
                          View
                        </a>
                      </Button>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      {getMediaIcon(media.type)}
                      <Badge variant="secondary" className="text-xs">
                        {media.type}
                      </Badge>
                    </div>
                    <h3 className="font-semibold text-white mb-1">{media.title}</h3>
                    {media.description && (
                      <p className="text-slate-400 text-sm line-clamp-2">{media.description}</p>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center h-48 text-center">
                <Video className="w-12 h-12 text-slate-400 mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">No media yet</h3>
                <p className="text-slate-400 mb-4">Share your performances, recordings, and portfolio</p>
                <Button onClick={() => setMediaDialogOpen(true)} className="forest-gradient">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Your First Media
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Experience Tab */}
        <TabsContent value="experience" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold text-white">Experience</h2>
            <Dialog open={experienceDialogOpen} onOpenChange={setExperienceDialogOpen}>
              <DialogTrigger asChild>
                <Button className="forest-gradient hover:opacity-90">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Experience
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Experience</DialogTitle>
                </DialogHeader>
                <Form {...experienceForm}>
                  <form onSubmit={experienceForm.handleSubmit((data) => addExperienceMutation.mutate(data))} className="space-y-4">
                    <FormField
                      control={experienceForm.control}
                      name="type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Type</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select experience type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="band">Band</SelectItem>
                              <SelectItem value="gig">Gig</SelectItem>
                              <SelectItem value="education">Education</SelectItem>
                              <SelectItem value="award">Award</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={experienceForm.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Title/Position</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., Lead Guitarist, Vocalist" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={experienceForm.control}
                      name="organization"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Organization/Band</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., The Rock Band, Local Symphony" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={experienceForm.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Location</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g., New York, NY" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={experienceForm.control}
                        name="startDate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Start Date</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={experienceForm.control}
                        name="endDate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>End Date (Optional)</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <FormField
                      control={experienceForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Describe your role and achievements" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button type="submit" className="w-full forest-gradient" disabled={addExperienceMutation.isPending}>
                      {addExperienceMutation.isPending ? "Adding..." : "Add Experience"}
                    </Button>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>

          {experiencesLoading ? (
            <div className="space-y-4">
              {[...Array(4)].map((_, i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-6">
                    <div className="h-4 bg-slate-700 rounded mb-2 w-1/3"></div>
                    <div className="h-3 bg-slate-700 rounded mb-2 w-1/2"></div>
                    <div className="h-3 bg-slate-700 rounded w-2/3"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : userExperiences.length > 0 ? (
            <div className="space-y-4">
              {userExperiences.map((exp: UserExperience) => (
                <Card key={exp.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="p-2 rounded-lg bg-forest-900/50 text-forest-400">
                        {getExperienceIcon(exp.type)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-white">{exp.title}</h3>
                          <Badge variant="outline" className="text-xs">
                            {exp.type}
                          </Badge>
                        </div>
                        {exp.organization && (
                          <p className="text-forest-400 font-medium mb-2">{exp.organization}</p>
                        )}
                        <div className="flex items-center gap-4 text-sm text-slate-400 mb-3">
                          {exp.startDate && (
                            <div className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              <span>
                                {format(new Date(exp.startDate), "MMM yyyy")} - {" "}
                                {exp.endDate ? format(new Date(exp.endDate), "MMM yyyy") : "Present"}
                              </span>
                            </div>
                          )}
                          {exp.location && (
                            <div className="flex items-center gap-1">
                              <MapPin className="w-3 h-3" />
                              <span>{exp.location}</span>
                            </div>
                          )}
                        </div>
                        {exp.description && (
                          <p className="text-slate-300 leading-relaxed">{exp.description}</p>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center h-48 text-center">
                <Briefcase className="w-12 h-12 text-slate-400 mb-4" />
                <h3 className="text-lg font-semibold text-white mb-2">No experience added yet</h3>
                <p className="text-slate-400 mb-4">Share your musical journey, performances, and achievements</p>
                <Button onClick={() => setExperienceDialogOpen(true)} className="forest-gradient">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Your First Experience
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}