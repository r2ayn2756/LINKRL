import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Send, MoreVertical } from "lucide-react";
import Sidebar from "@/components/layout/sidebar";

export default function Messages() {
  return (
    <div className="pt-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2">
          <Card className="bg-slate-dark-900 border-gray-700 h-[700px]">
            <CardContent className="p-0 h-full flex">
              {/* Conversations List */}
              <div className="w-1/3 border-r border-gray-700 flex flex-col">
                <div className="p-4 border-b border-gray-700">
                  <h2 className="text-xl font-semibold text-gray-100 mb-4">Messages</h2>
                  <div className="relative">
                    <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <Input
                      placeholder="Search conversations..."
                      className="pl-10 bg-slate-dark-850 border-gray-600 text-gray-200"
                    />
                  </div>
                </div>
                
                <div className="flex-1 overflow-y-auto">
                  <div className="space-y-1 p-2">
                    {/* Example conversations */}
                    <div className="p-3 hover:bg-slate-dark-850 rounded-lg cursor-pointer border-l-2 border-forest-500 bg-slate-dark-850">
                      <div className="flex items-center space-x-3">
                        <img
                          src="https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40"
                          alt="Maya Rodriguez"
                          className="w-10 h-10 rounded-full object-cover"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-start">
                            <h4 className="font-medium text-gray-200 text-sm truncate">Maya Rodriguez</h4>
                            <span className="text-xs text-gray-400">2h</span>
                          </div>
                          <p className="text-xs text-gray-400 truncate">Thanks for the collaboration opportunity!</p>
                        </div>
                      </div>
                    </div>

                    <div className="p-3 hover:bg-slate-dark-850 rounded-lg cursor-pointer">
                      <div className="flex items-center space-x-3">
                        <img
                          src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40"
                          alt="Jake Thompson"
                          className="w-10 h-10 rounded-full object-cover"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-start">
                            <h4 className="font-medium text-gray-200 text-sm truncate">Jake Thompson</h4>
                            <span className="text-xs text-gray-400">1d</span>
                          </div>
                          <p className="text-xs text-gray-400 truncate">Are you still looking for a bass player?</p>
                        </div>
                      </div>
                    </div>

                    <div className="p-3 hover:bg-slate-dark-850 rounded-lg cursor-pointer">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-forest-600 rounded-full flex items-center justify-center">
                          <span className="text-white text-sm font-medium">TR</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-start">
                            <h4 className="font-medium text-gray-200 text-sm truncate">The Rustic Stage</h4>
                            <span className="text-xs text-gray-400">3d</span>
                          </div>
                          <p className="text-xs text-gray-400 truncate">Your application has been approved!</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Chat Area */}
              <div className="flex-1 flex flex-col">
                {/* Chat Header */}
                <div className="p-4 border-b border-gray-700 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <img
                      src="https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40"
                      alt="Maya Rodriguez"
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div>
                      <h3 className="font-semibold text-gray-100">Maya Rodriguez</h3>
                      <p className="text-sm text-forest-400">Singer-Songwriter</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm">
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  <div className="flex">
                    <div className="max-w-xs lg:max-w-md">
                      <div className="bg-slate-dark-850 rounded-lg p-3">
                        <p className="text-gray-200 text-sm">Hey! I saw your post about looking for a collaborator. I'd love to work on some music together!</p>
                      </div>
                      <p className="text-xs text-gray-400 mt-1">Maya • 2 hours ago</p>
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <div className="max-w-xs lg:max-w-md">
                      <div className="bg-forest-600 rounded-lg p-3">
                        <p className="text-white text-sm">That sounds amazing! I checked out your profile and your style would be perfect for what I'm working on.</p>
                      </div>
                      <p className="text-xs text-gray-400 mt-1 text-right">You • 2 hours ago</p>
                    </div>
                  </div>

                  <div className="flex">
                    <div className="max-w-xs lg:max-w-md">
                      <div className="bg-slate-dark-850 rounded-lg p-3">
                        <p className="text-gray-200 text-sm">Thanks for the collaboration opportunity! When would be a good time to meet and discuss ideas?</p>
                      </div>
                      <p className="text-xs text-gray-400 mt-1">Maya • 1 hour ago</p>
                    </div>
                  </div>
                </div>

                {/* Message Input */}
                <div className="p-4 border-t border-gray-700">
                  <div className="flex space-x-2">
                    <Input
                      placeholder="Type a message..."
                      className="flex-1 bg-slate-dark-850 border-gray-600 text-gray-200"
                    />
                    <Button className="bg-forest-600 hover:bg-forest-700 text-white">
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Sidebar */}
        <div className="lg:col-span-1">
          <Sidebar />
        </div>
      </div>
    </div>
  );
}
