import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Music, Users, Calendar, MapPin, Star, ArrowRight } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-slate-dark-950 text-gray-100">
      {/* Header */}
      <header className="border-b border-gray-700 bg-slate-dark-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="forest-gradient w-8 h-8 rounded-lg flex items-center justify-center">
                <Music className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold forest-text">GigRL</span>
            </div>
            <Button 
              onClick={() => window.location.href = '/api/login'}
              className="bg-forest-600 hover:bg-forest-700 text-white"
            >
              Sign In with Google
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl font-bold mb-6">
            Connect. Create. <span className="forest-text">Perform.</span>
          </h1>
          <p className="text-xl text-gray-300 mb-8">
            The premier platform for musicians, venues, and music lovers to discover, 
            connect, and create incredible musical experiences together.
          </p>
          <Button 
            size="lg"
            onClick={() => window.location.href = '/api/login'}
            className="bg-forest-600 hover:bg-forest-700 text-white px-8 py-3 text-lg"
          >
            Get Started <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-slate-dark-900">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose GigRL?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-slate-dark-850 border-gray-700">
              <CardContent className="p-6 text-center">
                <Users className="w-12 h-12 forest-text mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Network with Musicians</h3>
                <p className="text-gray-400">
                  Connect with fellow musicians, find bandmates, and build your professional network.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-dark-850 border-gray-700">
              <CardContent className="p-6 text-center">
                <Calendar className="w-12 h-12 forest-text mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Discover Gigs</h3>
                <p className="text-gray-400">
                  Find performing opportunities at venues near you and apply directly through the platform.
                </p>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-dark-850 border-gray-700">
              <CardContent className="p-6 text-center">
                <Star className="w-12 h-12 forest-text mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">Showcase Talent</h3>
                <p className="text-gray-400">
                  Share your performances, build your portfolio, and get discovered by venues and fans.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Join the Community?</h2>
          <p className="text-xl text-gray-300 mb-8">
            Join thousands of musicians, venues, and music lovers on GigRL.
          </p>
          <Button 
            size="lg"
            onClick={() => window.location.href = '/api/login'}
            className="bg-forest-600 hover:bg-forest-700 text-white px-8 py-3 text-lg"
          >
            Sign Up Now
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-700 bg-slate-dark-900 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="forest-gradient w-6 h-6 rounded flex items-center justify-center">
              <Music className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold forest-text">GigRL</span>
          </div>
          <p className="text-gray-400">© 2025 GigRL. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
