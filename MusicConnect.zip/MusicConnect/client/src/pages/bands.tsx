import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Users, MapPin, Music, Plus } from "lucide-react";
import Sidebar from "@/components/layout/sidebar";

export default function Bands() {
  const { user } = useAuth();

  const { data: bands, isLoading } = useQuery({
    queryKey: ["/api/bands"],
    enabled: !!user,
  });

  return (
    <div className="pt-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-gray-100">Find Your Band</h1>
            <Button className="bg-forest-600 hover:bg-forest-700 text-white">
              <Plus className="w-4 h-4 mr-2" />
              Create Band
            </Button>
          </div>

          {/* Search and Filters */}
          <Card className="bg-slate-dark-900 border-gray-700">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="Search bands by name, genre, location..."
                    className="pl-10 bg-slate-dark-850 border-gray-600 text-gray-200"
                  />
                </div>
                <Button className="bg-forest-600 hover:bg-forest-700 text-white">
                  Search
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Band Listings */}
          <div className="space-y-6">
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="bg-slate-dark-900 rounded-xl border border-gray-700 p-6 animate-pulse">
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-slate-dark-850 rounded-full"></div>
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-slate-dark-850 rounded w-1/4"></div>
                        <div className="h-4 bg-slate-dark-850 rounded w-1/2"></div>
                        <div className="h-20 bg-slate-dark-850 rounded"></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : bands && bands.length > 0 ? (
              bands.map((band: any) => (
                <Card key={band.id} className="bg-slate-dark-900 border-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <img
                        src={band.imageUrl || band.creator?.profileImageUrl || "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60"}
                        alt={band.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <div>
                            <h4 className="font-semibold text-gray-100">{band.name}</h4>
                            <p className="text-forest-400 text-sm">
                              Created by {band.creator?.firstName} {band.creator?.lastName}
                            </p>
                          </div>
                        </div>
                        
                        <p className="text-gray-300 mb-4">{band.description}</p>
                        
                        {band.lookingFor && band.lookingFor.length > 0 && (
                          <div className="bg-slate-dark-850 rounded-lg p-4 mb-4">
                            <h6 className="font-medium text-gray-200 mb-3">Looking for:</h6>
                            <div className="flex flex-wrap gap-2">
                              {band.lookingFor.map((role: string, index: number) => (
                                <Badge key={index} variant="outline" className="border-forest-600 text-forest-400">
                                  {role}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        <div className="flex items-center space-x-4 text-sm text-gray-400 mb-4">
                          {band.location && (
                            <span className="flex items-center space-x-1">
                              <MapPin className="w-4 h-4" />
                              <span>{band.location}</span>
                            </span>
                          )}
                          {band.genre && (
                            <span className="flex items-center space-x-1">
                              <Music className="w-4 h-4" />
                              <span>{band.genre}</span>
                            </span>
                          )}
                          <span className="flex items-center space-x-1">
                            <Users className="w-4 h-4" />
                            <span>{band.memberCount || 1} members</span>
                          </span>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex -space-x-2">
                            <img 
                              src={band.creator?.profileImageUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40"} 
                              alt={`${band.creator?.firstName} ${band.creator?.lastName}`}
                              className="w-8 h-8 rounded-full border-2 border-slate-dark-900 object-cover" 
                            />
                            {band.memberCount > 1 && (
                              <div className="w-8 h-8 bg-forest-600 rounded-full border-2 border-slate-dark-900 flex items-center justify-center text-white text-xs font-medium">
                                +{band.memberCount - 1}
                              </div>
                            )}
                          </div>
                          <Button className="bg-forest-600 hover:bg-forest-700 text-white">
                            Express Interest
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card className="bg-slate-dark-900 border-gray-700">
                <CardContent className="p-8 text-center">
                  <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-200 mb-2">No Bands Found</h3>
                  <p className="text-gray-400 mb-4">Be the first to create a band in your area!</p>
                  <Button className="bg-forest-600 hover:bg-forest-700 text-white">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Your Band
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="lg:col-span-1">
          <Sidebar />
        </div>
      </div>
    </div>
  );
}
