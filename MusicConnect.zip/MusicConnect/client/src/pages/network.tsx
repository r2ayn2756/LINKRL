import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Search, UserPlus, MessageCircle, Users, UserX, Check } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState, useEffect } from "react";
import ProfileSidebar from "@/components/layout/ProfileSidebar";
import { type User } from "@shared/schema";

export default function Network() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState("");

  // Debounce search term to avoid too many API calls
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  const { data: connections = [], isLoading: connectionsLoading } = useQuery({
    queryKey: ["/api/connections"],
    enabled: !!user,
  });

  const { data: suggestions = [], isLoading: suggestionsLoading } = useQuery({
    queryKey: ["/api/connections/suggestions", { limit: 10 }],
    enabled: !!user,
  });

  const { data: searchResults = [], isLoading: searchLoading } = useQuery({
    queryKey: ["/api/users/search", debouncedSearchTerm],
    queryFn: () => apiRequest("GET", `/api/users/search?q=${encodeURIComponent(debouncedSearchTerm)}&limit=10`),
    enabled: !!debouncedSearchTerm && debouncedSearchTerm.trim().length > 0,
  });

  const connectMutation = useMutation({
    mutationFn: async (targetId: string) => {
      return apiRequest("POST", "/api/connections", { targetId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
      queryClient.invalidateQueries({ queryKey: ["/api/connections/suggestions"] });
      toast({
        title: "Connection request sent",
        description: "Your connection request has been sent successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send connection request. Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="pt-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Search Bar */}
          <Card className="bg-slate-dark-900 border-gray-700">
            <CardContent className="p-6">
              <div className="relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search musicians, venues, industry professionals..."
                  className="pl-10 bg-slate-dark-850 border-gray-600 text-gray-200"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </CardContent>
          </Card>

          {/* Search Results or Connection Suggestions */}
          <Card className="bg-slate-dark-900 border-gray-700">
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold text-gray-100 mb-4">
                {searchTerm ? `Search Results for "${searchTerm}"` : "People You May Know"}
              </h2>
              
              {searchTerm ? (
                // Search Results
                searchLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-forest-500 mx-auto"></div>
                    <p className="text-gray-400 mt-2">Searching...</p>
                  </div>
                ) : searchResults.length > 0 ? (
                  <div className="space-y-4">
                    {searchResults.map((person: User) => (
                      <div key={person.id} className="flex items-center space-x-4 p-4 bg-slate-dark-850 rounded-lg">
                        <img
                          src={person.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80"}
                          alt={`${person.firstName} ${person.lastName}`}
                          className="w-16 h-16 rounded-full object-cover"
                        />
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-100">
                            {person.firstName} {person.lastName}
                          </h3>
                          <p className="text-forest-400 text-sm">{person.title || "Musician"}</p>
                          <p className="text-gray-400 text-sm">{person.email}</p>
                        </div>
                        <div className="flex space-x-2">
                          <Button 
                            size="sm" 
                            className="bg-forest-600 hover:bg-forest-700 text-white"
                            onClick={() => connectMutation.mutate(person.id)}
                            disabled={connectMutation.isPending}
                          >
                            <UserPlus className="w-4 h-4 mr-1" />
                            {connectMutation.isPending ? "Connecting..." : "Connect"}
                          </Button>
                          <Button size="sm" variant="outline" className="border-gray-600">
                            <MessageCircle className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-400">No users found matching "{searchTerm}"</p>
                  </div>
                )
              ) : (
                // Connection Suggestions 
                suggestionsLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center space-x-4 animate-pulse">
                      <div className="w-16 h-16 bg-slate-dark-850 rounded-full"></div>
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-slate-dark-850 rounded w-1/3"></div>
                        <div className="h-3 bg-slate-dark-850 rounded w-1/2"></div>
                      </div>
                      <div className="w-20 h-8 bg-slate-dark-850 rounded"></div>
                    </div>
                  ))}
                </div>
              ) : suggestions.length > 0 ? (
                <div className="space-y-4">
                  {suggestions.map((person: any) => (
                    <div key={person.id} className="flex items-center space-x-4 p-4 bg-slate-dark-850 rounded-lg">
                      <img
                        src={person.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80"}
                        alt={`${person.firstName} ${person.lastName}`}
                        className="w-16 h-16 rounded-full object-cover"
                      />
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-100">
                          {person.firstName} {person.lastName}
                        </h3>
                        <p className="text-forest-400 text-sm">{person.title}</p>
                        <p className="text-gray-400 text-sm">{person.location}</p>
                      </div>
                      <div className="flex space-x-2">
                        <Button 
                          size="sm" 
                          className="bg-forest-600 hover:bg-forest-700 text-white"
                          onClick={() => connectMutation.mutate(person.id)}
                          disabled={connectMutation.isPending}
                        >
                          <UserPlus className="w-4 h-4 mr-1" />
                          {connectMutation.isPending ? "Connecting..." : "Connect"}
                        </Button>
                        <Button size="sm" variant="outline" className="border-gray-600">
                          <MessageCircle className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-400 text-center py-8">No suggestions available at the moment.</p>
              ))}
            </CardContent>
          </Card>

          {/* Your Connections */}
          <Card className="bg-slate-dark-900 border-gray-700">
            <CardContent className="p-6">
              <h2 className="text-xl font-semibold text-gray-100 mb-4">Your Network</h2>
              {connectionsLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex items-center space-x-4 animate-pulse">
                      <div className="w-12 h-12 bg-slate-dark-850 rounded-full"></div>
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-slate-dark-850 rounded w-1/4"></div>
                        <div className="h-3 bg-slate-dark-850 rounded w-1/3"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : connections.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {connections.map((connection: any) => {
                    const otherUser = connection.requester.id === user?.id ? connection.target : connection.requester;
                    return (
                      <div key={connection.id} className="flex items-center space-x-3 p-3 bg-slate-dark-850 rounded-lg">
                        <img
                          src={otherUser.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50"}
                          alt={`${otherUser.firstName} ${otherUser.lastName}`}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-200 text-sm">
                            {otherUser.firstName} {otherUser.lastName}
                          </h4>
                          <p className="text-forest-400 text-xs">{otherUser.title}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="text-gray-400 text-center py-8">You haven't made any connections yet. Start networking!</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right Sidebar */}
        <div className="lg:col-span-1">
          <ProfileSidebar />
        </div>
      </div>
    </div>
  );
}
