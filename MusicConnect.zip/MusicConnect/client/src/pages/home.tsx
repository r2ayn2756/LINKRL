import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import CreatePost from "@/components/posts/create-post";
import VideoPost from "@/components/posts/video-post";
import GigPost from "@/components/posts/gig-post";
import BandPost from "@/components/posts/band-post";
import TrendingWidget from "@/components/widgets/trending";

export default function Home() {
  const { user } = useAuth();
  
  const { data: feedPosts, isLoading } = useQuery({
    queryKey: ["/api/posts/feed"],
    enabled: !!user,
  });

  if (isLoading) {
    return (
      <div className="pt-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-slate-dark-900 rounded-xl border border-gray-700 p-6 animate-pulse">
                <div className="h-20 bg-slate-dark-850 rounded mb-4"></div>
                <div className="h-4 bg-slate-dark-850 rounded mb-2"></div>
                <div className="h-4 bg-slate-dark-850 rounded w-2/3"></div>
              </div>
            ))}
          </div>
          <div className="lg:col-span-1">
            <div className="bg-slate-dark-900 rounded-xl border border-gray-700 p-6 animate-pulse">
              <div className="h-40 bg-slate-dark-850 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content Feed */}
        <div className="lg:col-span-2 space-y-6">
          <CreatePost />
          
          {feedPosts && feedPosts.length > 0 ? (
            feedPosts.map((post: any) => {
              if (post.type === "video") {
                return <VideoPost key={post.id} post={post} />;
              } else if (post.type === "gig") {
                return <GigPost key={post.id} post={post} />;
              } else if (post.type === "band") {
                return <BandPost key={post.id} post={post} />;
              } else {
                return (
                  <div key={post.id} className="bg-slate-dark-900 rounded-xl border border-gray-700 p-6">
                    <div className="flex items-start space-x-4">
                      <img 
                        src={post.author?.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60"} 
                        alt={`${post.author?.firstName} ${post.author?.lastName}`}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <h4 className="font-semibold text-gray-100">
                            {post.author?.firstName} {post.author?.lastName}
                          </h4>
                          {post.author?.title && (
                            <span className="text-forest-400 text-sm">• {post.author.title}</span>
                          )}
                        </div>
                        <p className="text-gray-400 text-sm">
                          {new Date(post.createdAt).toLocaleTimeString()}
                        </p>
                        <p className="mt-4 text-gray-200">{post.content}</p>
                      </div>
                    </div>
                  </div>
                );
              }
            })
          ) : (
            <div className="bg-slate-dark-900 rounded-xl border border-gray-700 p-8 text-center">
              <p className="text-gray-400">No posts yet. Create your first post to get started!</p>
            </div>
          )}
          
          <TrendingWidget />
        </div>
        
        {/* Right Sidebar */}
        <div className="lg:col-span-1">
          <Sidebar />
        </div>
      </div>
    </div>
  );
}
