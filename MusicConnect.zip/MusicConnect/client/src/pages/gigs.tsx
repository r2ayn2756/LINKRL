import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Calendar, MapPin, DollarSign, Users, Clock } from "lucide-react";
import Sidebar from "@/components/layout/sidebar";
import { useToast } from "@/hooks/use-toast";

export default function Gigs() {
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: gigs, isLoading } = useQuery({
    queryKey: ["/api/gigs"],
    enabled: !!user,
  });

  const applyToGigMutation = useMutation({
    mutationFn: async ({ gigId, message }: { gigId: number; message: string }) => {
      await apiRequest("POST", `/api/gigs/${gigId}/apply`, { message });
    },
    onSuccess: () => {
      toast({
        title: "Application Sent",
        description: "Your gig application has been sent successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/gigs"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send application. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleApplyToGig = (gigId: number) => {
    applyToGigMutation.mutate({ gigId, message: "I'm interested in this opportunity!" });
  };

  return (
    <div className="pt-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Search and Filters */}
          <Card className="bg-slate-dark-900 border-gray-700">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                  <Input
                    placeholder="Search gigs by venue, genre, location..."
                    className="pl-10 bg-slate-dark-850 border-gray-600 text-gray-200"
                  />
                </div>
                <Button className="bg-forest-600 hover:bg-forest-700 text-white">
                  Search
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Gig Listings */}
          <div className="space-y-6">
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="bg-slate-dark-900 rounded-xl border border-gray-700 p-6 animate-pulse">
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-slate-dark-850 rounded-full"></div>
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-slate-dark-850 rounded w-1/4"></div>
                        <div className="h-4 bg-slate-dark-850 rounded w-1/2"></div>
                        <div className="h-20 bg-slate-dark-850 rounded"></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : gigs && gigs.length > 0 ? (
              gigs.map((gig: any) => (
                <Card key={gig.id} className="bg-slate-dark-900 border-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <img
                        src={gig.venue?.profileImageUrl || "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60"}
                        alt={`${gig.venue?.firstName} ${gig.venue?.lastName}`}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <h4 className="font-semibold text-gray-100">
                              {gig.venue?.firstName} {gig.venue?.lastName}
                            </h4>
                            <Badge className="bg-forest-600 text-white">Venue</Badge>
                          </div>
                          <Button
                            onClick={() => handleApplyToGig(gig.id)}
                            disabled={applyToGigMutation.isPending}
                            className="bg-forest-600 hover:bg-forest-700 text-white"
                          >
                            {applyToGigMutation.isPending ? "Applying..." : "Apply"}
                          </Button>
                        </div>
                        
                        <div className="p-4 bg-gradient-to-r from-forest-900/20 to-forest-800/10 rounded-lg border border-forest-700/30 mb-4">
                          <div className="flex items-center space-x-2 mb-2">
                            <Calendar className="w-4 h-4 text-forest-400" />
                            <h5 className="font-semibold text-forest-300">{gig.title}</h5>
                          </div>
                          <p className="text-gray-300 mb-3">{gig.description}</p>
                          
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            {gig.date && (
                              <div className="flex items-center space-x-2 text-gray-400">
                                <Calendar className="w-4 h-4" />
                                <span>{new Date(gig.date).toLocaleDateString()}</span>
                              </div>
                            )}
                            {gig.pay && (
                              <div className="flex items-center space-x-2 text-gray-400">
                                <DollarSign className="w-4 h-4" />
                                <span>{gig.pay}</span>
                              </div>
                            )}
                            {gig.location && (
                              <div className="flex items-center space-x-2 text-gray-400">
                                <MapPin className="w-4 h-4" />
                                <span>{gig.location}</span>
                              </div>
                            )}
                            <div className="flex items-center space-x-2 text-gray-400">
                              <Users className="w-4 h-4" />
                              <span>{gig.applicationsCount || 0} applications</span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between text-gray-400 text-sm">
                          <span className="flex items-center space-x-1">
                            <Clock className="w-4 h-4" />
                            <span>Posted {new Date(gig.createdAt).toLocaleDateString()}</span>
                          </span>
                          <Badge variant={gig.status === "open" ? "default" : "secondary"}>
                            {gig.status}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card className="bg-slate-dark-900 border-gray-700">
                <CardContent className="p-8 text-center">
                  <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-200 mb-2">No Gigs Available</h3>
                  <p className="text-gray-400">Check back later for new gig opportunities!</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="lg:col-span-1">
          <Sidebar />
        </div>
      </div>
    </div>
  );
}
