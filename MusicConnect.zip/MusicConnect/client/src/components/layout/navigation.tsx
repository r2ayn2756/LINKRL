import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Bell, Search, Music, Home, Users, MessageCircle, Guitar, UsersRound } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

export default function Navigation() {
  const [location, setLocation] = useLocation();
  const { user } = useAuth();

  const navItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/network", icon: Users, label: "Network" },
    { path: "/messages", icon: MessageCircle, label: "Messages" },
    { path: "/gigs", icon: Guitar, label: "Gigs" },
    { path: "/bands", icon: UsersRound, label: "Bands" },
  ];

  return (
    <>
      {/* Desktop Navigation */}
      <nav className="bg-slate-dark-900 border-b border-gray-700 fixed top-0 left-0 right-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo and Brand */}
            <div className="flex items-center space-x-8">
              <button 
                onClick={() => setLocation('/')}
                className="flex items-center space-x-2 hover:opacity-80 transition-opacity"
              >
                <div className="forest-gradient w-8 h-8 rounded-lg flex items-center justify-center">
                  <Music className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold forest-text">GigRL</span>
              </button>
              
              {/* Search Bar */}
              <div className="hidden md:block relative">
                <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                <Input 
                  placeholder="Search musicians, venues, gigs..." 
                  className="pl-10 w-80 bg-slate-dark-850 border-gray-600 text-gray-200"
                />
              </div>
            </div>

            {/* Main Navigation Tabs */}
            <div className="hidden md:flex items-center space-x-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = location === item.path;
                return (
                  <button
                    key={item.path}
                    onClick={() => setLocation(item.path)}
                    className={`flex flex-col items-center px-4 py-2 rounded-lg transition-all ${
                      isActive
                        ? "text-forest-400 bg-forest-900/20"
                        : "text-gray-400 hover:text-forest-400 hover:bg-forest-900/10"
                    }`}
                  >
                    <Icon className="w-5 h-5 mb-1" />
                    <span className="text-xs font-medium">{item.label}</span>
                  </button>
                );
              })}
            </div>

            {/* User Menu */}
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="w-5 h-5" />
                <div className="absolute -top-1 -right-1 bg-forest-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  2
                </div>
              </Button>
              
              <div className="relative">
                <img 
                  src={user?.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"} 
                  alt="Profile"
                  className="w-8 h-8 rounded-full object-cover border-2 border-forest-500 cursor-pointer"
                  onClick={() => setLocation('/profile')}
                />
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-slate-dark-900 border-t border-gray-700 z-50">
        <div className="grid grid-cols-5 h-16">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            return (
              <button
                key={item.path}
                onClick={() => setLocation(item.path)}
                className={`flex flex-col items-center justify-center ${
                  isActive
                    ? "text-forest-400 bg-forest-900/20"
                    : "text-gray-400 hover:text-forest-400"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs mt-1">{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </>
  );
}
