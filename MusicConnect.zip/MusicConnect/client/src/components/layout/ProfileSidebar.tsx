import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Edit, Share2, UserPlus, Heart, Calendar, Users } from "lucide-react";
import { Link } from "wouter";

export default function ProfileSidebar() {
  const { user } = useAuth();

  const { data: userStats } = useQuery({
    queryKey: ["/api/users", user?.id, "stats"],
    enabled: !!user?.id,
  });

  const { data: suggestions } = useQuery({
    queryKey: ["/api/connections/suggestions", { limit: 3 }],
    enabled: !!user,
  });

  if (!user) return null;

  const activities = [
    {
      icon: UserPlus,
      text: `Connected with Sarah Chen`,
      time: "2 hours ago",
      color: "bg-blue-600",
    },
    {
      icon: Heart,
      text: "Liked Maya's acoustic performance",
      time: "5 hours ago",
      color: "bg-forest-600",
    },
    {
      icon: Calendar,
      text: "Applied to gig at The Rustic Stage",
      time: "1 day ago",
      color: "bg-purple-600",
    },
  ];

  const upcomingGigs = [
    {
      title: "Jazz Night",
      venue: "The Blue Note",
      date: "March 15, 8 PM",
      status: "Confirmed",
      statusColor: "bg-forest-600",
    },
    {
      title: "Open Mic",
      venue: "Corner Café", 
      date: "March 20, 7 PM",
      status: "Pending",
      statusColor: "bg-yellow-600",
    },
  ];

  return (
    <div className="space-y-6 sticky top-20 self-start">
      {/* User Profile Card */}
      <Card className="bg-slate-dark-900 border-gray-700 shadow-xl overflow-hidden">
        {/* Profile Header Background */}
        <div className="h-20 bg-gradient-to-r from-forest-600 to-forest-800 relative">
          <div className="absolute -bottom-8 left-4">
            <Link href="/profile">
              <img 
                src={user?.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80"} 
                alt="Profile"
                className="w-16 h-16 rounded-full border-4 border-slate-dark-900 object-cover shadow-lg cursor-pointer hover:ring-2 hover:ring-forest-400 transition-all"
              />
            </Link>
          </div>
        </div>
        
        <CardContent className="pt-10 p-6">
          <div className="mb-4">
            <h3 className="text-lg font-semibold text-gray-100">
              {user?.firstName} {user?.lastName}
            </h3>
            <p className="text-forest-400 text-sm">{user?.title || "Multi-instrumentalist & Producer"}</p>
            <p className="text-gray-400 text-xs mt-1">{user?.location || "Los Angeles, CA"}</p>
          </div>
          
          {/* Profile Stats */}
          <div className="grid grid-cols-3 gap-4 text-center py-4 border-t border-b border-gray-700">
            <div>
              <p className="text-lg font-semibold text-forest-400">
                {userStats?.connections || 482}
              </p>
              <p className="text-xs text-gray-400">Connections</p>
            </div>
            <div>
              <p className="text-lg font-semibold text-forest-400">
                {userStats?.gigs || 23}
              </p>
              <p className="text-xs text-gray-400">Gigs</p>
            </div>
            <div>
              <p className="text-lg font-semibold text-forest-400">
                {userStats?.profileViews || "1.2K"}
              </p>
              <p className="text-xs text-gray-400">Profile Views</p>
            </div>
          </div>
          
          {/* Quick Actions */}
          <div className="mt-4 space-y-2">
            <Button asChild className="w-full bg-forest-600 hover:bg-forest-700 text-white font-medium transition-colors">
              <Link href="/profile">
                <Edit className="w-4 h-4 mr-2" />
                Edit Profile
              </Link>
            </Button>
            <Button variant="outline" className="w-full border-forest-600 text-forest-400 hover:bg-forest-900/20 font-medium transition-colors">
              <Share2 className="w-4 h-4 mr-2" />
              Share Profile
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {/* Recent Activity Widget */}
      <Card className="bg-slate-dark-900 border-gray-700 p-6 shadow-xl">
        <h4 className="text-lg font-semibold text-gray-100 mb-4">Recent Activity</h4>
        
        <div className="space-y-4">
          {activities?.map((activity, index) => {
            const Icon = activity.icon;
            return (
              <div key={index} className="flex items-start space-x-3">
                <div className={`w-8 h-8 ${activity.color} rounded-full flex items-center justify-center flex-shrink-0`}>
                  <Icon className="text-white text-xs" />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-gray-300">{activity.text}</p>
                  <p className="text-xs text-gray-400">{activity.time}</p>
                </div>
              </div>
            );
          })}
        </div>
      </Card>
      
      {/* Upcoming Gigs Widget */}
      <Card className="bg-slate-dark-900 border-gray-700 p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-lg font-semibold text-gray-100">Upcoming Gigs</h4>
          <Button variant="ghost" size="sm" className="text-forest-400 hover:text-forest-300 text-sm">
            View All
          </Button>
        </div>
        
        <div className="space-y-3">
          {upcomingGigs.map((gig, index) => (
            <div key={index} className="p-3 bg-slate-dark-850 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <h5 className="font-medium text-gray-200">{gig.title}</h5>
                <Badge className={`${gig.statusColor} text-white text-xs px-2 py-1 rounded-full`}>
                  {gig.status}
                </Badge>
              </div>
              <p className="text-sm text-gray-400">{gig.venue} • {gig.date}</p>
            </div>
          ))}
        </div>
      </Card>
      
      {/* Suggestions Widget */}
      {suggestions && suggestions.length > 0 && (
        <Card className="bg-slate-dark-900 border-gray-700 p-6 shadow-xl">
          <h4 className="text-lg font-semibold text-gray-100 mb-4">People You May Know</h4>
          
          <div className="space-y-4">
            {suggestions.map((person: any) => (
              <div key={person.id} className="flex items-center space-x-3">
                <img 
                  src={person.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50"} 
                  alt={`${person.firstName} ${person.lastName}`}
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div className="flex-1">
                  <h5 className="font-medium text-gray-200 text-sm">
                    {person.firstName} {person.lastName}
                  </h5>
                  <p className="text-xs text-gray-400">{person.title}</p>
                </div>
                <Button size="sm" className="bg-forest-600 hover:bg-forest-700 text-white px-3 py-1 text-xs font-medium transition-colors">
                  Connect
                </Button>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
