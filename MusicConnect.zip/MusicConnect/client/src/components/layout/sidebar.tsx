import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Edit, Share2, UserPlus, Heart, Calendar, Users } from "lucide-react";
import RecentActivity from "@/components/widgets/recent-activity";
import UpcomingGigs from "@/components/widgets/upcoming-gigs";
import Suggestions from "@/components/widgets/suggestions";

export default function Sidebar() {
  const { user } = useAuth();

  const { data: userStats } = useQuery({
    queryKey: ["/api/users", user?.id, "stats"],
    enabled: !!user?.id,
  });

  if (!user) return null;

  return (
    <div className="space-y-6 sticky top-20">
      {/* User Profile Card */}
      <Card className="bg-slate-dark-900 border-gray-700 overflow-hidden">
        {/* Profile Header Background */}
        <div className="h-20 forest-gradient relative">
          <div className="absolute -bottom-8 left-4">
            <img 
              src={user.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=80&h=80"} 
              alt="Profile"
              className="w-16 h-16 rounded-full border-4 border-slate-dark-900 object-cover shadow-lg"
            />
          </div>
        </div>
        
        <CardContent className="pt-10 p-6">
          <div className="mb-4">
            <h3 className="text-lg font-semibold text-gray-100">
              {user.firstName} {user.lastName}
            </h3>
            <p className="text-forest-400 text-sm">{user.title || "Musician"}</p>
            <p className="text-gray-400 text-xs mt-1">{user.location}</p>
          </div>
          
          {/* Profile Stats */}
          <div className="grid grid-cols-3 gap-4 text-center py-4 border-t border-b border-gray-700">
            <div>
              <p className="text-lg font-semibold text-forest-400">
                {userStats?.connections || 0}
              </p>
              <p className="text-xs text-gray-400">Connections</p>
            </div>
            <div>
              <p className="text-lg font-semibold text-forest-400">
                {userStats?.gigs || 0}
              </p>
              <p className="text-xs text-gray-400">Gigs</p>
            </div>
            <div>
              <p className="text-lg font-semibold text-forest-400">
                {userStats?.profileViews || 0}
              </p>
              <p className="text-xs text-gray-400">Profile Views</p>
            </div>
          </div>
          
          {/* Quick Actions */}
          <div className="mt-4 space-y-2">
            <Button className="w-full bg-forest-600 hover:bg-forest-700 text-white">
              <Edit className="w-4 h-4 mr-2" />
              Edit Profile
            </Button>
            <Button variant="outline" className="w-full border-forest-600 text-forest-400 hover:bg-forest-900/20">
              <Share2 className="w-4 h-4 mr-2" />
              Share Profile
            </Button>
          </div>
        </CardContent>
      </Card>
      
      <RecentActivity />
      <UpcomingGigs />
      <Suggestions />
    </div>
  );
}
