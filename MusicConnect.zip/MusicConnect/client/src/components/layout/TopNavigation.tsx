import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Bell, Search, Music, Home, Users, MessageCircle, Guitar, UsersRound } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

export default function TopNavigation() {
  const [location, setLocation] = useLocation();
  const { user } = useAuth();

  const navItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/network", icon: Users, label: "Network" },
    { path: "/messages", icon: MessageCircle, label: "Messages" },
    { path: "/gigs", icon: Guitar, label: "Gigs" },
    { path: "/bands", icon: UsersRound, label: "Bands" },
  ];

  return (
    <nav className="bg-slate-dark-900 border-b border-gray-700 sticky top-0 z-50 shadow-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-forest-500 to-forest-700 rounded-lg flex items-center justify-center">
                <Music className="text-white text-sm" />
              </div>
              <span className="text-xl font-bold text-forest-400">GigRL</span>
            </div>
            
            {/* Search Bar */}
            <div className="hidden md:block relative">
              <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
              <Input 
                placeholder="Search musicians, venues, gigs..." 
                className="pl-10 pr-4 py-2 bg-slate-dark-850 text-gray-200 border-gray-600 focus:border-forest-500 focus:ring-1 focus:ring-forest-500 w-80"
              />
            </div>
          </div>

          {/* Main Navigation Tabs */}
          <div className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location === item.path;
              return (
                <button
                  key={item.path}
                  onClick={() => setLocation(item.path)}
                  className={`flex flex-col items-center px-4 py-2 rounded-lg transition-all relative ${
                    isActive
                      ? "text-forest-400 bg-forest-900/20"
                      : "text-gray-400 hover:text-forest-400 hover:bg-forest-900/10"
                  }`}
                >
                  <Icon className="text-lg mb-1" />
                  <span className="text-xs font-medium">{item.label}</span>
                  {item.label === "Messages" && (
                    <div className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                      3
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          {/* User Menu */}
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="p-2 text-gray-400 hover:text-forest-400 transition-colors relative">
              <Bell className="text-lg" />
              <div className="absolute -top-1 -right-1 bg-forest-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                2
              </div>
            </Button>
            
            <div className="relative">
              <img 
                src={user?.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&h=100"} 
                alt="Profile"
                className="w-8 h-8 rounded-full object-cover border-2 border-forest-500 cursor-pointer"
                onClick={() => window.location.href = '/api/logout'}
              />
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
