import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Clock, Star, MoreHorizontal } from "lucide-react";

interface BandCardProps {
  post: any;
}

export default function BandCard({ post }: BandCardProps) {
  const bandData = post.metadata || {};
  const lookingFor = bandData.lookingFor || ["Bass Player", "Drummer", "Lead Vocalist"];

  return (
    <Card className="bg-slate-dark-900 rounded-xl border border-gray-700 shadow-xl overflow-hidden">
      <CardContent className="p-6">
        <div className="flex items-start space-x-4">
          <img 
            src={post.author?.profileImageUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60"} 
            alt={`${post.author?.firstName} ${post.author?.lastName}`}
            className="w-12 h-12 rounded-full object-cover"
          />
          <div className="flex-1">
            <div className="flex items-center space-x-2">
              <h4 className="font-semibold text-gray-100">
                {post.author?.firstName} {post.author?.lastName}
              </h4>
              <span className="text-forest-400 text-sm">• {post.author?.title}</span>
            </div>
            <p className="text-gray-400 text-sm">
              {new Date(post.createdAt).toLocaleTimeString()}
            </p>
          </div>
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-300">
            <MoreHorizontal />
          </Button>
        </div>
        
        <div className="mt-4">
          <h5 className="text-lg font-semibold text-forest-300 mb-2">
            🎸 {bandData.name || "Forming Alternative Rock Band - \"Midnight Echoes\""}
          </h5>
          <p className="text-gray-300 mb-4">{post.content}</p>
          
          <div className="bg-slate-dark-850 rounded-lg p-4 mb-4">
            <h6 className="font-medium text-gray-200 mb-3">Looking for:</h6>
            <div className="grid grid-cols-2 gap-2">
              {lookingFor.map((role: string, index: number) => (
                <div key={index} className="flex items-center space-x-2 text-sm">
                  <div className={`w-2 h-2 rounded-full ${
                    index === 0 ? "bg-red-500" : index === 1 ? "bg-yellow-500" : "bg-green-500"
                  }`}></div>
                  <span className="text-gray-300">{role}</span>
                  {index === 0 && <span className="text-red-400 text-xs">(Urgent)</span>}
                  {index === 2 && <span className="text-green-400 text-xs">(Optional)</span>}
                </div>
              ))}
            </div>
          </div>
          
          <div className="flex items-center space-x-4 text-sm text-gray-400 mb-4">
            <span className="flex items-center space-x-1">
              <MapPin className="w-4 h-4" />
              <span>{bandData.location || post.author?.location || "Seattle Area"}</span>
            </span>
            <span className="flex items-center space-x-1">
              <Clock className="w-4 h-4" />
              <span>{bandData.frequency || "2-3x per week"}</span>
            </span>
            <span className="flex items-center space-x-1">
              <Star className="w-4 h-4" />
              <span>{bandData.level || "Intermediate-Advanced"}</span>
            </span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex -space-x-2">
              <img 
                src={post.author?.profileImageUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40"} 
                alt={`${post.author?.firstName} ${post.author?.lastName}`}
                className="w-8 h-8 rounded-full border-2 border-slate-dark-900 object-cover" 
              />
              <img 
                src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40" 
                alt="Sarah Chen"
                className="w-8 h-8 rounded-full border-2 border-slate-dark-900 object-cover" 
              />
              <div className="w-8 h-8 bg-forest-600 rounded-full border-2 border-slate-dark-900 flex items-center justify-center text-white text-xs font-medium">
                +{bandData.memberCount || 2}
              </div>
            </div>
            <Button className="bg-forest-600 hover:bg-forest-700 text-white px-6 py-2 rounded-lg text-sm font-medium transition-colors">
              Express Interest
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
