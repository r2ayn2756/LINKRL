import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, DollarSign, Users, Guitar, MoreHorizontal } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface GigCardProps {
  post: any;
}

export default function GigCard({ post }: GigCardProps) {
  const { toast } = useToast();

  const applyToGigMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", `/api/gigs/${post.id}/apply`, { 
        message: "I'm interested in this opportunity!" 
      });
    },
    onSuccess: () => {
      toast({
        title: "Application Sent",
        description: "Your gig application has been sent successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/posts/feed"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send application. Please try again.",
        variant: "destructive",
      });
    },
  });

  const gigData = post.metadata || {};

  return (
    <Card className="bg-slate-dark-900 rounded-xl border border-gray-700 shadow-xl overflow-hidden">
      <CardContent className="p-6">
        <div className="flex items-start space-x-4">
          <img 
            src={post.author?.profileImageUrl || "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60"} 
            alt={`${post.author?.firstName} ${post.author?.lastName}`}
            className="w-12 h-12 rounded-full object-cover"
          />
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <h4 className="font-semibold text-gray-100">
                  {post.author?.firstName} {post.author?.lastName}
                </h4>
                <Badge className="bg-forest-600 text-white text-xs px-2 py-1 rounded-full">Venue</Badge>
              </div>
              <Button 
                onClick={() => applyToGigMutation.mutate()}
                disabled={applyToGigMutation.isPending}
                className="bg-forest-600 hover:bg-forest-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
              >
                {applyToGigMutation.isPending ? "Applying..." : "Apply"}
              </Button>
            </div>
            <p className="text-gray-400 text-sm">
              {new Date(post.createdAt).toLocaleTimeString()}
            </p>
          </div>
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-300">
            <MoreHorizontal />
          </Button>
        </div>
        
        <div className="mt-4 p-4 bg-gradient-to-r from-forest-900/20 to-forest-800/10 rounded-lg border border-forest-700/30">
          <div className="flex items-center space-x-2 mb-2">
            <Guitar className="text-forest-400" />
            <h5 className="font-semibold text-forest-300">{gigData.title || "Looking for Musicians"}</h5>
          </div>
          <p className="text-gray-300 mb-3">{post.content}</p>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center space-x-2 text-gray-400">
              <Calendar className="w-4 h-4" />
              <span>{gigData.schedule || "Saturdays 7-9 PM"}</span>
            </div>
            <div className="flex items-center space-x-2 text-gray-400">
              <DollarSign className="w-4 h-4" />
              <span>{gigData.pay || "$200-300 per show"}</span>
            </div>
            <div className="flex items-center space-x-2 text-gray-400">
              <MapPin className="w-4 h-4" />
              <span>{gigData.location || post.author?.location || "Downtown Portland"}</span>
            </div>
            <div className="flex items-center space-x-2 text-gray-400">
              <Users className="w-4 h-4" />
              <span>{gigData.capacity || "150"} capacity</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center justify-between mt-4 text-gray-400 text-sm">
          <span>{gigData.interested || 24} interested</span>
          <span>{gigData.applications || 5} applications</span>
        </div>
      </CardContent>
    </Card>
  );
}
