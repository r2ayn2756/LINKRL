import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, Share, Play, CheckCircle, MoreHorizontal } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface PostCardProps {
  post: any;
}

export default function PostCard({ post }: PostCardProps) {
  const { toast } = useToast();

  const likeMutation = useMutation({
    mutationFn: async () => {
      if (post.isLiked) {
        await apiRequest("DELETE", `/api/posts/${post.id}/like`);
      } else {
        await apiRequest("POST", `/api/posts/${post.id}/like`);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts/feed"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update like. Please try again.",
        variant: "destructive",
      });
    },
  });

  const renderVideoPost = () => (
    <>
      {/* Video Player */}
      <div className="relative bg-black">
        <img 
          src={post.mediaUrl || "https://images.unsplash.com/photo-1516280440614-37939bbacd81?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450"} 
          alt="Live acoustic performance"
          className="w-full h-64 object-cover"
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <Button className="bg-forest-600 hover:bg-forest-700 text-white rounded-full w-16 h-16 flex items-center justify-center shadow-lg transition-colors">
            <Play className="ml-1" />
          </Button>
        </div>
        <div className="absolute bottom-4 right-4 bg-black/70 text-white px-2 py-1 rounded text-sm">
          3:42
        </div>
      </div>
    </>
  );

  return (
    <Card className="bg-slate-dark-900 rounded-xl border border-gray-700 shadow-xl overflow-hidden">
      <CardContent className="p-6">
        <div className="flex items-start space-x-4">
          <img 
            src={post.author?.profileImageUrl || "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60"} 
            alt={`${post.author?.firstName} ${post.author?.lastName}`}
            className="w-12 h-12 rounded-full object-cover"
          />
          <div className="flex-1">
            <div className="flex items-center space-x-2">
              <h4 className="font-semibold text-gray-100">
                {post.author?.firstName} {post.author?.lastName}
              </h4>
              <span className="text-forest-400 text-sm">• {post.author?.title}</span>
              <CheckCircle className="text-forest-500 text-xs" />
            </div>
            <p className="text-gray-400 text-sm">
              {new Date(post.createdAt).toLocaleTimeString()}
            </p>
          </div>
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-gray-300">
            <MoreHorizontal />
          </Button>
        </div>
        
        <p className="mt-4 text-gray-200">{post.content}</p>
      </CardContent>
      
      {post.type === "video" && renderVideoPost()}
      
      {/* Post Interactions */}
      <CardContent className="p-6 border-t border-gray-700">
        <div className="flex items-center justify-between text-gray-400 text-sm mb-4">
          <span>{post.likesCount || 0} likes</span>
          <span>{post.commentsCount || 0} comments</span>
        </div>
        
        <div className="flex items-center space-x-1">
          <Button 
            variant="ghost" 
            className={`flex-1 flex items-center justify-center space-x-2 py-2 text-gray-400 hover:text-forest-400 hover:bg-slate-dark-850 rounded-lg transition-colors ${
              post.isLiked ? 'text-forest-400' : ''
            }`}
            onClick={() => likeMutation.mutate()}
            disabled={likeMutation.isPending}
          >
            <Heart className={`text-sm ${post.isLiked ? 'fill-current' : ''}`} />
            <span className="text-sm">Like</span>
          </Button>
          <Button variant="ghost" className="flex-1 flex items-center justify-center space-x-2 py-2 text-gray-400 hover:text-forest-400 hover:bg-slate-dark-850 rounded-lg transition-colors">
            <MessageCircle className="text-sm" />
            <span className="text-sm">Comment</span>
          </Button>
          <Button variant="ghost" className="flex-1 flex items-center justify-center space-x-2 py-2 text-gray-400 hover:text-forest-400 hover:bg-slate-dark-850 rounded-lg transition-colors">
            <Share className="text-sm" />
            <span className="text-sm">Share</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
