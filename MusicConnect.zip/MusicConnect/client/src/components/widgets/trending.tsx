import { Card, CardContent } from "@/components/ui/card";
import { Hash, Mic, Disc } from "lucide-react";

const trendingItems = [
  {
    icon: Hash,
    title: "#OpenMicNight",
    subtitle: "2.3K posts this week",
    color: "from-forest-500 to-forest-700",
  },
  {
    icon: Mic,
    title: "Local Music Festival",
    subtitle: "850 musicians interested",
    color: "from-purple-500 to-purple-700",
  },
  {
    icon: Disc,
    title: "Indie Rock Revival",
    subtitle: "1.2K discussions",
    color: "from-orange-500 to-orange-700",
  },
];

export default function TrendingWidget() {
  return (
    <Card className="bg-slate-dark-900 border-gray-700">
      <CardContent className="p-6">
        <h3 className="text-lg font-semibold text-gray-100 mb-4">🔥 Trending This Week</h3>
        
        <div className="space-y-4">
          {trendingItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <div 
                key={index}
                className="flex items-center space-x-3 p-3 bg-slate-dark-850 rounded-lg hover:bg-slate-dark-800 transition-colors cursor-pointer"
              >
                <div className={`w-12 h-12 bg-gradient-to-br ${item.color} rounded-lg flex items-center justify-center`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-200">{item.title}</p>
                  <p className="text-sm text-gray-400">{item.subtitle}</p>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
