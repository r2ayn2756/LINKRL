import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const upcomingGigs = [
  {
    title: "Jazz Night",
    venue: "The Blue Note",
    date: "March 15, 8 PM",
    status: "Confirmed",
    statusColor: "bg-forest-600",
  },
  {
    title: "Open Mic",
    venue: "Corner Café",
    date: "March 20, 7 PM",
    status: "Pending",
    statusColor: "bg-yellow-600",
  },
];

export default function UpcomingGigs() {
  return (
    <Card className="bg-slate-dark-900 border-gray-700">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-lg font-semibold text-gray-100">Upcoming Gigs</h4>
          <Button variant="ghost" size="sm" className="text-forest-400 hover:text-forest-300">
            View All
          </Button>
        </div>
        
        <div className="space-y-3">
          {upcomingGigs.map((gig, index) => (
            <div key={index} className="p-3 bg-slate-dark-850 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <h5 className="font-medium text-gray-200">{gig.title}</h5>
                <Badge className={`${gig.statusColor} text-white`}>
                  {gig.status}
                </Badge>
              </div>
              <p className="text-sm text-gray-400">{gig.venue} • {gig.date}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
