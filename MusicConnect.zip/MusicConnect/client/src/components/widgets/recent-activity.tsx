import { Card, CardContent } from "@/components/ui/card";
import { UserPlus, Heart, Calendar } from "lucide-react";

const activities = [
  {
    icon: UserPlus,
    text: "Connected with Sarah Chen",
    time: "2 hours ago",
    color: "bg-blue-600",
  },
  {
    icon: Heart,
    text: "Liked Maya's acoustic performance",
    time: "5 hours ago",
    color: "bg-forest-600",
  },
  {
    icon: Calendar,
    text: "Applied to gig at The Rustic Stage",
    time: "1 day ago",
    color: "bg-purple-600",
  },
];

export default function RecentActivity() {
  return (
    <Card className="bg-slate-dark-900 border-gray-700">
      <CardContent className="p-6">
        <h4 className="text-lg font-semibold text-gray-100 mb-4">Recent Activity</h4>
        
        <div className="space-y-4">
          {activities.map((activity, index) => {
            const Icon = activity.icon;
            return (
              <div key={index} className="flex items-start space-x-3">
                <div className={`w-8 h-8 ${activity.color} rounded-full flex items-center justify-center flex-shrink-0`}>
                  <Icon className="w-4 h-4 text-white" />
                </div>
                <div className="flex-1">
                  <p className="text-sm text-gray-300">{activity.text}</p>
                  <p className="text-xs text-gray-400">{activity.time}</p>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
