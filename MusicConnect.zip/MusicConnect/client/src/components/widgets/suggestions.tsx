import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function Suggestions() {
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: suggestions } = useQuery({
    queryKey: ["/api/connections/suggestions", { limit: 3 }],
    enabled: !!user,
  });

  const connectMutation = useMutation({
    mutationFn: async (targetId: string) => {
      await apiRequest("POST", "/api/connections", { targetId });
    },
    onSuccess: () => {
      toast({
        title: "Connection request sent",
        description: "Your connection request has been sent successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/connections/suggestions"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send connection request. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (!suggestions || suggestions.length === 0) return null;

  return (
    <Card className="bg-slate-dark-900 border-gray-700">
      <CardContent className="p-6">
        <h4 className="text-lg font-semibold text-gray-100 mb-4">People You May Know</h4>
        
        <div className="space-y-4">
          {suggestions.map((person: any) => (
            <div key={person.id} className="flex items-center space-x-3">
              <img 
                src={person.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50"} 
                alt={`${person.firstName} ${person.lastName}`}
                className="w-10 h-10 rounded-full object-cover"
              />
              <div className="flex-1">
                <h5 className="font-medium text-gray-200 text-sm">
                  {person.firstName} {person.lastName}
                </h5>
                <p className="text-xs text-gray-400">{person.title}</p>
              </div>
              <Button 
                size="sm"
                onClick={() => connectMutation.mutate(person.id)}
                disabled={connectMutation.isPending}
                className="bg-forest-600 hover:bg-forest-700 text-white"
              >
                {connectMutation.isPending ? "..." : "Connect"}
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
