import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Image, Video, Calendar } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function CreatePost() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [content, setContent] = useState("");

  const createPostMutation = useMutation({
    mutationFn: async (postData: any) => {
      await apiRequest("POST", "/api/posts", postData);
    },
    onSuccess: () => {
      setContent("");
      toast({
        title: "Post created",
        description: "Your post has been shared successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/posts/feed"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create post. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    if (!content.trim()) return;
    
    createPostMutation.mutate({
      content: content.trim(),
      type: "text",
    });
  };

  if (!user) return null;

  return (
    <Card className="bg-slate-dark-900 border-gray-700">
      <CardContent className="p-6">
        <div className="flex items-start space-x-4">
          <img 
            src={user.profileImageUrl || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60"} 
            alt="Your profile"
            className="w-12 h-12 rounded-full object-cover"
          />
          <div className="flex-1">
            <Textarea 
              placeholder="Share your latest performance, song, or musical thoughts..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full bg-slate-dark-850 border-gray-600 text-gray-200 resize-none"
              rows={3}
            />
            
            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center space-x-4">
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-forest-400">
                  <Image className="w-4 h-4 mr-2" />
                  Photo
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-forest-400">
                  <Video className="w-4 h-4 mr-2" />
                  Video
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-forest-400">
                  <Calendar className="w-4 h-4 mr-2" />
                  Gig
                </Button>
              </div>
              <Button 
                onClick={handleSubmit}
                disabled={!content.trim() || createPostMutation.isPending}
                className="bg-forest-600 hover:bg-forest-700 text-white"
              >
                {createPostMutation.isPending ? "Posting..." : "Post"}
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
