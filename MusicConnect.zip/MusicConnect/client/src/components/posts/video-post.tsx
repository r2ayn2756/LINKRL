import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, Share, Play, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface VideoPostProps {
  post: any;
}

export default function VideoPost({ post }: VideoPostProps) {
  const { toast } = useToast();

  const likeMutation = useMutation({
    mutationFn: async () => {
      if (post.isLiked) {
        await apiRequest("DELETE", `/api/posts/${post.id}/like`);
      } else {
        await apiRequest("POST", `/api/posts/${post.id}/like`);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/posts/feed"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update like. Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <Card className="bg-slate-dark-900 border-gray-700 overflow-hidden">
      <CardContent className="p-6">
        <div className="flex items-start space-x-4">
          <img 
            src={post.author?.profileImageUrl || "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60"} 
            alt={`${post.author?.firstName} ${post.author?.lastName}`}
            className="w-12 h-12 rounded-full object-cover"
          />
          <div className="flex-1">
            <div className="flex items-center space-x-2">
              <h4 className="font-semibold text-gray-100">
                {post.author?.firstName} {post.author?.lastName}
              </h4>
              <span className="text-forest-400 text-sm">• {post.author?.title}</span>
              <CheckCircle className="w-4 h-4 text-forest-500" />
            </div>
            <p className="text-gray-400 text-sm">
              {new Date(post.createdAt).toLocaleTimeString()}
            </p>
          </div>
        </div>
        
        <p className="mt-4 text-gray-200">{post.content}</p>
      </CardContent>
      
      {/* Video Player */}
      <div className="relative bg-black">
        <img 
          src={post.mediaUrl || "https://images.unsplash.com/photo-1516280440614-37939bbacd81?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=450"} 
          alt="Video thumbnail"
          className="w-full h-64 object-cover"
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <Button className="bg-forest-600 hover:bg-forest-700 text-white rounded-full w-16 h-16">
            <Play className="w-6 h-6 ml-1" />
          </Button>
        </div>
        <div className="absolute bottom-4 right-4 bg-black/70 text-white px-2 py-1 rounded text-sm">
          3:42
        </div>
      </div>
      
      {/* Post Interactions */}
      <CardContent className="p-6 border-t border-gray-700">
        <div className="flex items-center justify-between text-gray-400 text-sm mb-4">
          <span>{post.likesCount || 0} likes</span>
          <span>{post.commentsCount || 0} comments</span>
        </div>
        
        <div className="flex items-center space-x-1">
          <Button 
            variant="ghost" 
            className={`flex-1 ${post.isLiked ? 'text-forest-400' : 'text-gray-400 hover:text-forest-400'}`}
            onClick={() => likeMutation.mutate()}
            disabled={likeMutation.isPending}
          >
            <Heart className={`w-4 h-4 mr-2 ${post.isLiked ? 'fill-current' : ''}`} />
            Like
          </Button>
          <Button variant="ghost" className="flex-1 text-gray-400 hover:text-forest-400">
            <MessageCircle className="w-4 h-4 mr-2" />
            Comment
          </Button>
          <Button variant="ghost" className="flex-1 text-gray-400 hover:text-forest-400">
            <Share className="w-4 h-4 mr-2" />
            Share
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
