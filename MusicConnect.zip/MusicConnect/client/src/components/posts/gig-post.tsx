import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, DollarSign, Users, Guitar } from "lucide-react";

interface GigPostProps {
  post: any;
}

export default function GigPost({ post }: GigPostProps) {
  const gigData = post.metadata || {};

  return (
    <Card className="bg-slate-dark-900 border-gray-700 overflow-hidden">
      <CardContent className="p-6">
        <div className="flex items-start space-x-4">
          <img 
            src={post.author?.profileImageUrl || "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?ixlib=rb-4.0.3&auto=format&fit=crop&w=60&h=60"} 
            alt={`${post.author?.firstName} ${post.author?.lastName}`}
            className="w-12 h-12 rounded-full object-cover"
          />
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <h4 className="font-semibold text-gray-100">
                  {post.author?.firstName} {post.author?.lastName}
                </h4>
                <Badge className="bg-forest-600 text-white">Venue</Badge>
              </div>
              <Button className="bg-forest-600 hover:bg-forest-700 text-white">
                Apply
              </Button>
            </div>
            <p className="text-gray-400 text-sm">
              {new Date(post.createdAt).toLocaleTimeString()}
            </p>
          </div>
        </div>
        
        <div className="mt-4 p-4 bg-gradient-to-r from-forest-900/20 to-forest-800/10 rounded-lg border border-forest-700/30">
          <div className="flex items-center space-x-2 mb-2">
            <Guitar className="w-4 h-4 text-forest-400" />
            <h5 className="font-semibold text-forest-300">{gigData.title || "Gig Opportunity"}</h5>
          </div>
          <p className="text-gray-300 mb-3">{post.content}</p>
          
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center space-x-2 text-gray-400">
              <Calendar className="w-4 h-4" />
              <span>{gigData.schedule || "Weekends"}</span>
            </div>
            <div className="flex items-center space-x-2 text-gray-400">
              <DollarSign className="w-4 h-4" />
              <span>{gigData.pay || "$200-300 per show"}</span>
            </div>
            <div className="flex items-center space-x-2 text-gray-400">
              <MapPin className="w-4 h-4" />
              <span>{gigData.location || post.author?.location}</span>
            </div>
            <div className="flex items-center space-x-2 text-gray-400">
              <Users className="w-4 h-4" />
              <span>{gigData.capacity || "150"} capacity</span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center justify-between mt-4 text-gray-400 text-sm">
          <span>{gigData.interested || 24} interested</span>
          <span>{gigData.applications || 5} applications</span>
        </div>
      </CardContent>
    </Card>
  );
}
