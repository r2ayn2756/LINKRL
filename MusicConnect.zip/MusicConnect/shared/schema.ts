import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (required for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  title: varchar("title"), // e.g., "Singer-Songwriter", "Guitarist"
  location: varchar("location"),
  bio: text("bio"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  authorId: varchar("author_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  type: varchar("type").notNull(), // "text", "video", "gig", "band"
  mediaUrl: varchar("media_url"),
  metadata: jsonb("metadata"), // For gig details, band requirements, etc.
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const connections = pgTable("connections", {
  id: serial("id").primaryKey(),
  requesterId: varchar("requester_id").notNull().references(() => users.id),
  targetId: varchar("target_id").notNull().references(() => users.id),
  status: varchar("status").notNull().default("pending"), // "pending", "accepted", "rejected"
  createdAt: timestamp("created_at").defaultNow(),
});

export const bands = pgTable("bands", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  description: text("description"),
  creatorId: varchar("creator_id").notNull().references(() => users.id),
  imageUrl: varchar("image_url"),
  location: varchar("location"),
  genre: varchar("genre"),
  lookingFor: text("looking_for").array(), // Array of roles needed
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const bandMembers = pgTable("band_members", {
  id: serial("id").primaryKey(),
  bandId: integer("band_id").notNull().references(() => bands.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  role: varchar("role").notNull(), // "creator", "member", "pending"
  instrument: varchar("instrument"),
  joinedAt: timestamp("joined_at").defaultNow(),
});

export const gigs = pgTable("gigs", {
  id: serial("id").primaryKey(),
  title: varchar("title").notNull(),
  description: text("description"),
  venueId: varchar("venue_id").notNull().references(() => users.id),
  location: varchar("location"),
  date: timestamp("date"),
  pay: varchar("pay"),
  requirements: text("requirements"),
  status: varchar("status").notNull().default("open"), // "open", "closed", "filled"
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const gigApplications = pgTable("gig_applications", {
  id: serial("id").primaryKey(),
  gigId: integer("gig_id").notNull().references(() => gigs.id),
  applicantId: varchar("applicant_id").notNull().references(() => users.id),
  message: text("message"),
  status: varchar("status").notNull().default("pending"), // "pending", "accepted", "rejected"
  appliedAt: timestamp("applied_at").defaultNow(),
});

export const likes = pgTable("likes", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull().references(() => posts.id),
  userId: varchar("user_id").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
});

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull().references(() => posts.id),
  authorId: varchar("author_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userMedia = pgTable("user_media", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  type: varchar("type").notNull(), // "video", "audio", "image"
  title: varchar("title").notNull(),
  description: text("description"),
  mediaUrl: varchar("media_url").notNull(),
  thumbnailUrl: varchar("thumbnail_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const userExperiences = pgTable("user_experiences", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").notNull().references(() => users.id),
  title: varchar("title").notNull(), // e.g., "Lead Guitarist at The Rock Band"
  organization: varchar("organization"), // e.g., "The Rock Band", "Symphony Orchestra"
  location: varchar("location"),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"), // null if current
  description: text("description"),
  type: varchar("type").notNull(), // "band", "gig", "education", "award"
  createdAt: timestamp("created_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  posts: many(posts),
  sentConnections: many(connections, { relationName: "requester" }),
  receivedConnections: many(connections, { relationName: "target" }),
  createdBands: many(bands),
  bandMemberships: many(bandMembers),
  createdGigs: many(gigs),
  gigApplications: many(gigApplications),
  likes: many(likes),
  comments: many(comments),
  media: many(userMedia),
  experiences: many(userExperiences),
}));

export const postsRelations = relations(posts, ({ one, many }) => ({
  author: one(users, {
    fields: [posts.authorId],
    references: [users.id],
  }),
  likes: many(likes),
  comments: many(comments),
}));

export const connectionsRelations = relations(connections, ({ one }) => ({
  requester: one(users, {
    fields: [connections.requesterId],
    references: [users.id],
    relationName: "requester",
  }),
  target: one(users, {
    fields: [connections.targetId],
    references: [users.id],
    relationName: "target",
  }),
}));

export const bandsRelations = relations(bands, ({ one, many }) => ({
  creator: one(users, {
    fields: [bands.creatorId],
    references: [users.id],
  }),
  members: many(bandMembers),
}));

export const bandMembersRelations = relations(bandMembers, ({ one }) => ({
  band: one(bands, {
    fields: [bandMembers.bandId],
    references: [bands.id],
  }),
  user: one(users, {
    fields: [bandMembers.userId],
    references: [users.id],
  }),
}));

export const gigsRelations = relations(gigs, ({ one, many }) => ({
  venue: one(users, {
    fields: [gigs.venueId],
    references: [users.id],
  }),
  applications: many(gigApplications),
}));

export const gigApplicationsRelations = relations(gigApplications, ({ one }) => ({
  gig: one(gigs, {
    fields: [gigApplications.gigId],
    references: [gigs.id],
  }),
  applicant: one(users, {
    fields: [gigApplications.applicantId],
    references: [users.id],
  }),
}));

export const likesRelations = relations(likes, ({ one }) => ({
  post: one(posts, {
    fields: [likes.postId],
    references: [posts.id],
  }),
  user: one(users, {
    fields: [likes.userId],
    references: [users.id],
  }),
}));

export const commentsRelations = relations(comments, ({ one }) => ({
  post: one(posts, {
    fields: [comments.postId],
    references: [posts.id],
  }),
  author: one(users, {
    fields: [comments.authorId],
    references: [users.id],
  }),
}));

export const userMediaRelations = relations(userMedia, ({ one }) => ({
  user: one(users, {
    fields: [userMedia.userId],
    references: [users.id],
  }),
}));

export const userExperiencesRelations = relations(userExperiences, ({ one }) => ({
  user: one(users, {
    fields: [userExperiences.userId],
    references: [users.id],
  }),
}));

// Schema types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export type InsertPost = typeof posts.$inferInsert;
export type Post = typeof posts.$inferSelect;

export type InsertConnection = typeof connections.$inferInsert;
export type Connection = typeof connections.$inferSelect;

export type InsertBand = typeof bands.$inferInsert;
export type Band = typeof bands.$inferSelect;

export type InsertBandMember = typeof bandMembers.$inferInsert;
export type BandMember = typeof bandMembers.$inferSelect;

export type InsertGig = typeof gigs.$inferInsert;
export type Gig = typeof gigs.$inferSelect;

export type InsertGigApplication = typeof gigApplications.$inferInsert;
export type GigApplication = typeof gigApplications.$inferSelect;

export type InsertLike = typeof likes.$inferInsert;
export type Like = typeof likes.$inferSelect;

export type InsertComment = typeof comments.$inferInsert;
export type Comment = typeof comments.$inferSelect;

export type InsertUserMedia = typeof userMedia.$inferInsert;
export type UserMedia = typeof userMedia.$inferSelect;

export type InsertUserExperience = typeof userExperiences.$inferInsert;
export type UserExperience = typeof userExperiences.$inferSelect;

// Insert schemas for validation
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPostSchema = createInsertSchema(posts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertConnectionSchema = createInsertSchema(connections).omit({
  id: true,
  createdAt: true,
});

export const insertBandSchema = createInsertSchema(bands).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertGigSchema = createInsertSchema(gigs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertGigApplicationSchema = createInsertSchema(gigApplications).omit({
  id: true,
  appliedAt: true,
});

export const insertUserMediaSchema = createInsertSchema(userMedia).omit({
  id: true,
  createdAt: true,
});

export const insertUserExperienceSchema = createInsertSchema(userExperiences).omit({
  id: true,
  createdAt: true,
});
