import {
  users,
  posts,
  connections,
  bands,
  bandMembers,
  gigs,
  gigApplications,
  likes,
  comments,
  userMedia,
  userExperiences,
  type User,
  type UpsertUser,
  type Post,
  type InsertPost,
  type Connection,
  type InsertConnection,
  type Band,
  type InsertBand,
  type Gig,
  type InsertGig,
  type InsertGigApplication,
  type InsertLike,
  type InsertComment,
  type UserMedia,
  type InsertUserMedia,
  type UserExperience,
  type InsertUserExperience,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, sql, count, like } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Post operations
  createPost(post: InsertPost): Promise<Post>;
  getFeedPosts(userId: string, limit: number, offset: number): Promise<(Post & { author: User; likesCount: number; commentsCount: number; isLiked: boolean })[]>;
  
  // Connection operations
  sendConnectionRequest(requesterId: string, targetId: string): Promise<Connection>;
  getConnections(userId: string): Promise<(Connection & { requester: User; target: User })[]>;
  getConnectionSuggestions(userId: string, limit: number): Promise<User[]>;
  
  // Band operations
  createBand(band: InsertBand): Promise<Band>;
  getBands(limit: number, offset: number): Promise<(Band & { creator: User; memberCount: number })[]>;
  getBandsByUser(userId: string): Promise<(Band & { creator: User })[]>;
  
  // Gig operations
  createGig(gig: InsertGig): Promise<Gig>;
  getGigs(limit: number, offset: number): Promise<(Gig & { venue: User; applicationsCount: number })[]>;
  applyToGig(application: InsertGigApplication): Promise<void>;
  
  // Interaction operations
  likePost(postId: number, userId: string): Promise<void>;
  unlikePost(postId: number, userId: string): Promise<void>;
  addComment(comment: InsertComment): Promise<void>;
  
  // Stats
  getUserStats(userId: string): Promise<{ connections: number; gigs: number; profileViews: number }>;
  
  // User media operations
  getUserMedia(userId: string): Promise<UserMedia[]>;
  createUserMedia(media: InsertUserMedia): Promise<UserMedia>;
  
  // User experience operations
  getUserExperiences(userId: string): Promise<UserExperience[]>;
  createUserExperience(experience: InsertUserExperience): Promise<UserExperience>;
  
  // User search
  searchUsers(query: string, limit: number): Promise<User[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Post operations
  async createPost(post: InsertPost): Promise<Post> {
    const [newPost] = await db.insert(posts).values(post).returning();
    return newPost;
  }

  async getFeedPosts(userId: string, limit: number, offset: number) {
    const feedPosts = await db
      .select({
        id: posts.id,
        authorId: posts.authorId,
        content: posts.content,
        type: posts.type,
        mediaUrl: posts.mediaUrl,
        metadata: posts.metadata,
        createdAt: posts.createdAt,
        updatedAt: posts.updatedAt,
        author: users,
        likesCount: sql<number>`cast(count(distinct ${likes.id}) as int)`,
        commentsCount: sql<number>`cast(count(distinct ${comments.id}) as int)`,
        isLiked: sql<boolean>`case when ${likes.userId} = ${userId} then true else false end`,
      })
      .from(posts)
      .leftJoin(users, eq(posts.authorId, users.id))
      .leftJoin(likes, eq(posts.id, likes.postId))
      .leftJoin(comments, eq(posts.id, comments.postId))
      .groupBy(posts.id, users.id, likes.userId)
      .orderBy(desc(posts.createdAt))
      .limit(limit)
      .offset(offset);

    return feedPosts;
  }

  // Connection operations
  async sendConnectionRequest(requesterId: string, targetId: string): Promise<Connection> {
    const [connection] = await db
      .insert(connections)
      .values({ requesterId, targetId })
      .returning();
    return connection;
  }

  async getConnections(userId: string) {
    const userConnections = await db
      .select({
        id: connections.id,
        requesterId: connections.requesterId,
        targetId: connections.targetId,
        status: connections.status,
        createdAt: connections.createdAt,
        requester: {
          id: users.id,
          email: users.email,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
          title: users.title,
          location: users.location,
          bio: users.bio,
          createdAt: users.createdAt,
          updatedAt: users.updatedAt,
        },
        target: {
          id: users.id,
          email: users.email,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
          title: users.title,
          location: users.location,
          bio: users.bio,
          createdAt: users.createdAt,
          updatedAt: users.updatedAt,
        },
      })
      .from(connections)
      .leftJoin(users, eq(connections.requesterId, users.id))
      .where(
        and(
          or(eq(connections.requesterId, userId), eq(connections.targetId, userId)),
          eq(connections.status, "accepted")
        )
      );

    return userConnections;
  }

  async getConnectionSuggestions(userId: string, limit: number): Promise<User[]> {
    const suggestions = await db
      .select()
      .from(users)
      .where(
        and(
          sql`${users.id} != ${userId}`,
          sql`${users.id} not in (
            select ${connections.targetId} from ${connections} where ${connections.requesterId} = ${userId}
            union
            select ${connections.requesterId} from ${connections} where ${connections.targetId} = ${userId}
          )`
        )
      )
      .limit(limit);

    return suggestions;
  }

  // Band operations
  async createBand(band: InsertBand): Promise<Band> {
    const [newBand] = await db.insert(bands).values(band).returning();
    return newBand;
  }

  async getBands(limit: number, offset: number) {
    const bandList = await db
      .select({
        id: bands.id,
        name: bands.name,
        description: bands.description,
        creatorId: bands.creatorId,
        imageUrl: bands.imageUrl,
        location: bands.location,
        genre: bands.genre,
        lookingFor: bands.lookingFor,
        createdAt: bands.createdAt,
        updatedAt: bands.updatedAt,
        creator: users,
        memberCount: sql<number>`cast(count(${bandMembers.id}) as int)`,
      })
      .from(bands)
      .leftJoin(users, eq(bands.creatorId, users.id))
      .leftJoin(bandMembers, eq(bands.id, bandMembers.bandId))
      .groupBy(bands.id, users.id)
      .orderBy(desc(bands.createdAt))
      .limit(limit)
      .offset(offset);

    return bandList;
  }

  async getBandsByUser(userId: string) {
    const userBands = await db
      .select({
        id: bands.id,
        name: bands.name,
        description: bands.description,
        creatorId: bands.creatorId,
        imageUrl: bands.imageUrl,
        location: bands.location,
        genre: bands.genre,
        lookingFor: bands.lookingFor,
        createdAt: bands.createdAt,
        updatedAt: bands.updatedAt,
        creator: users,
      })
      .from(bands)
      .leftJoin(users, eq(bands.creatorId, users.id))
      .where(eq(bands.creatorId, userId));

    return userBands;
  }

  // Gig operations
  async createGig(gig: InsertGig): Promise<Gig> {
    const [newGig] = await db.insert(gigs).values(gig).returning();
    return newGig;
  }

  async getGigs(limit: number, offset: number) {
    const gigList = await db
      .select({
        id: gigs.id,
        title: gigs.title,
        description: gigs.description,
        venueId: gigs.venueId,
        location: gigs.location,
        date: gigs.date,
        pay: gigs.pay,
        requirements: gigs.requirements,
        status: gigs.status,
        createdAt: gigs.createdAt,
        updatedAt: gigs.updatedAt,
        venue: users,
        applicationsCount: sql<number>`cast(count(${gigApplications.id}) as int)`,
      })
      .from(gigs)
      .leftJoin(users, eq(gigs.venueId, users.id))
      .leftJoin(gigApplications, eq(gigs.id, gigApplications.gigId))
      .groupBy(gigs.id, users.id)
      .orderBy(desc(gigs.createdAt))
      .limit(limit)
      .offset(offset);

    return gigList;
  }

  async applyToGig(application: InsertGigApplication): Promise<void> {
    await db.insert(gigApplications).values(application);
  }

  // Interaction operations
  async likePost(postId: number, userId: string): Promise<void> {
    await db.insert(likes).values({ postId, userId }).onConflictDoNothing();
  }

  async unlikePost(postId: number, userId: string): Promise<void> {
    await db.delete(likes).where(
      and(eq(likes.postId, postId), eq(likes.userId, userId))
    );
  }

  async addComment(comment: InsertComment): Promise<void> {
    await db.insert(comments).values(comment);
  }

  // Stats
  async getUserStats(userId: string): Promise<{ connections: number; gigs: number; profileViews: number }> {
    const [connectionsCount] = await db
      .select({ count: count() })
      .from(connections)
      .where(
        and(
          or(eq(connections.requesterId, userId), eq(connections.targetId, userId)),
          eq(connections.status, "accepted")
        )
      );

    const [gigsCount] = await db
      .select({ count: count() })
      .from(gigs)
      .where(eq(gigs.venueId, userId));

    return {
      connections: connectionsCount.count,
      gigs: gigsCount.count,
      profileViews: 1200, // Mock value for now
    };
  }

  // User media operations
  async getUserMedia(userId: string): Promise<UserMedia[]> {
    const media = await db
      .select()
      .from(userMedia)
      .where(eq(userMedia.userId, userId))
      .orderBy(desc(userMedia.createdAt));
    return media;
  }

  async createUserMedia(media: InsertUserMedia): Promise<UserMedia> {
    const [newMedia] = await db.insert(userMedia).values(media).returning();
    return newMedia;
  }

  // User experience operations
  async getUserExperiences(userId: string): Promise<UserExperience[]> {
    const experiences = await db
      .select()
      .from(userExperiences)
      .where(eq(userExperiences.userId, userId))
      .orderBy(desc(userExperiences.startDate));
    return experiences;
  }

  async createUserExperience(experience: InsertUserExperience): Promise<UserExperience> {
    const [newExperience] = await db.insert(userExperiences).values(experience).returning();
    return newExperience;
  }

  async searchUsers(query: string, limit: number = 10): Promise<User[]> {
    const searchTerm = `%${query.toLowerCase()}%`;
    const searchResults = await db
      .select()
      .from(users)
      .where(
        or(
          like(sql`LOWER(${users.firstName})`, searchTerm),
          like(sql`LOWER(${users.lastName})`, searchTerm),
          like(sql`LOWER(${users.email})`, searchTerm),
          like(sql`LOWER(${users.title})`, searchTerm)
        )
      )
      .limit(limit);
    
    return searchResults;
  }
}

export const storage = new DatabaseStorage();
