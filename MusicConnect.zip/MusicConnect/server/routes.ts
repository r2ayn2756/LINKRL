import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertPostSchema, insertBandSchema, insertGigSchema, insertGigApplicationSchema, insertConnectionSchema, insertUserMediaSchema, insertUserExperienceSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Posts routes
  app.post('/api/posts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const postData = insertPostSchema.parse({ ...req.body, authorId: userId });
      const post = await storage.createPost(postData);
      res.json(post);
    } catch (error) {
      console.error("Error creating post:", error);
      res.status(400).json({ message: "Failed to create post" });
    }
  });

  app.get('/api/posts/feed', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 10;
      const offset = parseInt(req.query.offset as string) || 0;
      const posts = await storage.getFeedPosts(userId, limit, offset);
      res.json(posts);
    } catch (error) {
      console.error("Error fetching feed:", error);
      res.status(500).json({ message: "Failed to fetch feed" });
    }
  });

  app.post('/api/posts/:id/like', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const postId = parseInt(req.params.id);
      await storage.likePost(postId, userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error liking post:", error);
      res.status(400).json({ message: "Failed to like post" });
    }
  });

  app.delete('/api/posts/:id/like', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const postId = parseInt(req.params.id);
      await storage.unlikePost(postId, userId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error unliking post:", error);
      res.status(400).json({ message: "Failed to unlike post" });
    }
  });

  // Connections routes
  app.post('/api/connections', isAuthenticated, async (req: any, res) => {
    try {
      const requesterId = req.user.claims.sub;
      const connectionData = insertConnectionSchema.parse({ ...req.body, requesterId });
      const connection = await storage.sendConnectionRequest(connectionData.requesterId, connectionData.targetId);
      res.json(connection);
    } catch (error) {
      console.error("Error sending connection request:", error);
      res.status(400).json({ message: "Failed to send connection request" });
    }
  });

  app.get('/api/connections', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const connections = await storage.getConnections(userId);
      res.json(connections);
    } catch (error) {
      console.error("Error fetching connections:", error);
      res.status(500).json({ message: "Failed to fetch connections" });
    }
  });

  app.get('/api/connections/suggestions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 5;
      const suggestions = await storage.getConnectionSuggestions(userId, limit);
      res.json(suggestions);
    } catch (error) {
      console.error("Error fetching suggestions:", error);
      res.status(500).json({ message: "Failed to fetch suggestions" });
    }
  });

  // Bands routes
  app.post('/api/bands', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bandData = insertBandSchema.parse({ ...req.body, creatorId: userId });
      const band = await storage.createBand(bandData);
      res.json(band);
    } catch (error) {
      console.error("Error creating band:", error);
      res.status(400).json({ message: "Failed to create band" });
    }
  });

  app.get('/api/bands', isAuthenticated, async (req: any, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const offset = parseInt(req.query.offset as string) || 0;
      const bands = await storage.getBands(limit, offset);
      res.json(bands);
    } catch (error) {
      console.error("Error fetching bands:", error);
      res.status(500).json({ message: "Failed to fetch bands" });
    }
  });

  app.get('/api/bands/user/:userId', isAuthenticated, async (req, res) => {
    try {
      const { userId } = req.params;
      const bands = await storage.getBandsByUser(userId);
      res.json(bands);
    } catch (error) {
      console.error("Error fetching user bands:", error);
      res.status(500).json({ message: "Failed to fetch user bands" });
    }
  });

  // Gigs routes
  app.post('/api/gigs', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const gigData = insertGigSchema.parse({ ...req.body, venueId: userId });
      const gig = await storage.createGig(gigData);
      res.json(gig);
    } catch (error) {
      console.error("Error creating gig:", error);
      res.status(400).json({ message: "Failed to create gig" });
    }
  });

  app.get('/api/gigs', isAuthenticated, async (req: any, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const offset = parseInt(req.query.offset as string) || 0;
      const gigs = await storage.getGigs(limit, offset);
      res.json(gigs);
    } catch (error) {
      console.error("Error fetching gigs:", error);
      res.status(500).json({ message: "Failed to fetch gigs" });
    }
  });

  app.post('/api/gigs/:id/apply', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const gigId = parseInt(req.params.id);
      const applicationData = insertGigApplicationSchema.parse({
        ...req.body,
        gigId,
        applicantId: userId,
      });
      await storage.applyToGig(applicationData);
      res.json({ success: true });
    } catch (error) {
      console.error("Error applying to gig:", error);
      res.status(400).json({ message: "Failed to apply to gig" });
    }
  });

  // User stats
  app.get('/api/users/:userId/stats', isAuthenticated, async (req, res) => {
    try {
      const { userId } = req.params;
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching user stats:", error);
      res.status(500).json({ message: "Failed to fetch user stats" });
    }
  });

  // User media routes
  app.get('/api/users/:userId/media', isAuthenticated, async (req, res) => {
    try {
      const { userId } = req.params;
      const media = await storage.getUserMedia(userId);
      res.json(media);
    } catch (error) {
      console.error("Error fetching user media:", error);
      res.status(500).json({ message: "Failed to fetch user media" });
    }
  });

  app.post('/api/users/media', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const mediaData = insertUserMediaSchema.parse({ ...req.body, userId });
      const media = await storage.createUserMedia(mediaData);
      res.json(media);
    } catch (error) {
      console.error("Error creating user media:", error);
      res.status(400).json({ message: "Failed to create user media" });
    }
  });

  // User experience routes
  app.get('/api/users/:userId/experiences', isAuthenticated, async (req, res) => {
    try {
      const { userId } = req.params;
      const experiences = await storage.getUserExperiences(userId);
      res.json(experiences);
    } catch (error) {
      console.error("Error fetching user experiences:", error);
      res.status(500).json({ message: "Failed to fetch user experiences" });
    }
  });

  app.post('/api/users/experiences', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const experienceData = insertUserExperienceSchema.parse({ ...req.body, userId });
      const experience = await storage.createUserExperience(experienceData);
      res.json(experience);
    } catch (error) {
      console.error("Error creating user experience:", error);
      res.status(400).json({ message: "Failed to create user experience" });
    }
  });

  // User search route
  app.get('/api/users/search', isAuthenticated, async (req, res) => {
    try {
      const { q: query, limit = 10 } = req.query;
      
      if (!query || typeof query !== 'string') {
        return res.json([]);
      }

      const results = await storage.searchUsers(query.trim(), parseInt(limit as string));
      res.json(results);
    } catch (error) {
      console.error("Error searching users:", error);
      res.status(500).json({ message: "Failed to search users" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
